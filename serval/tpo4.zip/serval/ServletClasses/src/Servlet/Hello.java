package Servlet;

import javax.servlet.http.*;
import java.io.*;
public class Hello extends HttpServlet {
//    @Override
//    public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException{
//        int i = Integer.parseInt(req.getParameter("num1"));
//        int j = Integer.parseInt(req.getParameter("num2"));
//        var s = res.getWriter();
//        s.print("<html><body>");
//        s.println("Result is " + (i+j));
//        s.print("</html></body>");
//    }
//
//    @Override
//    public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException{
//        doPost(req, res);
//    }
}
